Demos require a Mobiscroll trial or the licensed product.

The Mobiscroll Trial comes with a number of limitations including:
 - Always connected mode. When using a trial build you'll always have to be connected to the internet.
 - Unoptimized packages. The trial packages are not optimized for size, load speed and content.

These limitations are lifted with the purchase of a license. You will be able to build custom download packages that can be included in online and offline apps as well.

Please refer to the EULA - https://mobiscroll.com/EULA for more info.