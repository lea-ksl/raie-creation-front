    import { Component } from '@angular/core';
    import { mobiscroll, MbscRangeOptions } from '../lib/mobiscroll/js/mobiscroll.angular.min.js';
    
    mobiscroll.settings = {
        theme: 'ios',                       // Specify theme like: theme: 'ios' or omit setting to use default
        themeVariant: 'light',              // More info about themeVariant: https://docs.mobiscroll.com/4-10-2/angular/range#opt-themeVariant
        lang: 'fr'                          // Specify language like: lang: 'pl' or omit setting to use default
    };
    
    const now = new Date();
    const week = [now, new Date(now.getFullYear(), now.getMonth(), now.getDate() + 6, 23, 59)];
    
    @Component({
        selector: 'app-root',
        templateUrl: './app.component.html'
    })
    export class AppComponent {
        demo = week;
        range = week;
    
        demoSettings: MbscRangeOptions = {
            controls: ['calendar', 'time']  // More info about controls: https://docs.mobiscroll.com/4-10-2/angular/range#opt-controls
        };
    
        rangeSettings: MbscRangeOptions = {
            controls: ['date', 'time'],     // More info about controls: https://docs.mobiscroll.com/4-10-2/angular/range#opt-controls
            dateWheels: '|D M d|',          // More info about dateWheels: https://docs.mobiscroll.com/4-10-2/angular/range#localization-dateWheels
            cssClass: 'scroller-range'      // More info about cssClass: https://docs.mobiscroll.com/4-10-2/angular/range#opt-cssClass
        };
